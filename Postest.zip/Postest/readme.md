This test was originally presented on Chance, B., R. Delmas, and J. Garfield (2004). Reasoning about sampling distributions, pp. 295–323. Springer Science+Business Media Dordrecht. 

Slight changes were made.