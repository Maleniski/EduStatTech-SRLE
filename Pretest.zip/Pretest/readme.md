This test was derived from the following instruments:

Garfield, J., B. delMas, and B. Chance (2002). List of tools for sampling distributions. http://www.gen.umn.edu/faculty_staff/delmas/stat_tools/

Garfield, J. (2003). Assessing statistical reasoning. Statistics Education Research Jour-
nal 2.

Gormally, C., P. Brickman, and M. Lutz (2012). Developing a test of scientific literacy skills
(tosls): Measuring undergraduates’ evaluation of scientific information and arguments.
Life Sciences Education 11, 364–377.

LOCUS (2022). Sample items and commentaries for high school. https://locus.statisticseducation.org/
