---
title: Acerca de
subtitle: Sobre esta página
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/acercadeimg.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">

Esta página fue parte de la intervención didáctica realizada por María Elena Martínez Manzanares a estudiantes de Licenciatura en Ciencias de la Computación y Licenciatura en Matemáticas de la Universidad de Sonora durante el semestre 2023-2, como parte del proyecto terminal de la Licenciatura en Enseñanza de las Matemáticas de la Universidad Abierta y a Distancia de México. 


<h3><i class="fa-solid fa-circle-info"></i> Datos del proyecto</h3>
---

* **Nombre de la estudiante:** María Elena Martínez Manzanares
* **Nombre del asesor externo:** Dra. Gudelia Figueroa Preciado (Universidad de Sonora)
* **Asesor por medio de retribución social de CONAHCYT:** M.C. Irenisolina Antelo López (Universidad de Sonora)
* **Nombre del docente en línea:** Dra. Irene Carolina Pérez Oxté y Dra. Fátima Widman Aguayo (Universidad Abierta y a Distancia de México)

* **Nombre del proyecto terminal:** Uso de la tecnología como mediador del aprendizaje del tema distribución muestral de un estadístico  : un análisis comparativo


* **Objetivo:** Comparar y cuantificar diferencias presentadas en el aprendizaje del tema distribución muestral de un estadístico, bajo un muestreo aleatorio simple, en los estudiantes de Licenciatura en Matemáticas y Ciencias de la Computación de la Universidad de Sonora que cursan la asignatura de Estadística, cuando se exponen a experiencias de enseñanza mediadas por tecnología, en un caso bajo el enfoque denominado Statistical Reasoning Learning Environment (SRLE) y en el otro uno que no promueve este modelo pedagógico.

<style>
  .image-text-container {
    display: grid;
    grid-template-columns: auto 1fr;
    align-items: center;
    grid-gap: 20px;
  }
</style>

<div class="image-text-container">
  <div>
    <img src="https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/portada-libro.png" alt="Portada libro" style="width: 248;">
</div>
  <div>
    Este proyecto utilizó el modelo pedagógico para la enseñanza de la estadística a nivel universitario llamado Statistical Reasoning Learning Environment, propuesto en el libro "Developing students' statistical reasoning: Connecting research and teaching practice" de Garfield, Ben-Zvi, Chance, Medina, Roseth, y Zieffler. Basados en este modelo, los autores proponen en el Capítulo 12 una secuencia para la enseñanza de distribuciones muestrales, la cual fue traducida y adaptada para efectos de este trabajo.
 </div>
</div>


<h3><i class="fa-regular fa-id-badge"></i> Datos de contacto</h3>
---

* **LinkedIn de María Elena:** [malenamanzanares](https://www.linkedin.com/in/malenamanzanares/){:target="_blank"} 
* **Repositorio de GitHub de María Elena:** [maleniski](https://github.com/Maleniski){:target="_blank"} 
* **Portafolio de María Elena:** [malenamanzanares](https://www.datascienceportfol.io/malenamanzanares){:target="_blank"} 

---
![](https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/logo_unadm.jpeg)
![](https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/logo-unison.png)
