---
title: Actividad 1
subtitle: Muestreo aleatorio
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/1.jpg
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

1.	Entender que el parámetro de la población tiene un valor fijo, mientras que un estadístico toma valores que varían de una muestra a otra.
2.	Identificar el efecto de aumentar o disminuir el *número de muestras* y el *tamaño de la muestra* en un proceso de simulación.
3.	Identificar las características principales de algunos tipos de muestreos aleatorios.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

  * Cuando el docente te lo indique, observa este video.

<iframe width="560" height="315" src="https://www.youtube.com/embed/0x49kvFsYXQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

  * Te mostramos a continuación el discurso de Gettysburg en inglés. Espera instrucciones del docente.

> Four score and seven years ago our fathers brought forth on this continent, a new nation, conceived in Liberty, and dedicated to the proposition that all men are created equal.
> 
> Now we are engaged in a great civil war, testing whether that nation, or any nation so conceived and so dedicated, can long endure. We are met on a great battle-field of that war. We have come to dedicate a portion of that field, as a final resting place for those who here gave their lives that that nation might live. It is altogether fitting and proper that we should do this.
> 
> But, in a larger sense, we can not dedicate—we can not consecrate—we can not hallow—this ground. The brave men, living and dead, who struggled here, have consecrated it, far above our poor power to add or detract. The world will little note, nor long remember what we say here, but it can never forget what they did here. It is for us the living, rather, to be dedicated here to the unfinished work which they who fought here have thus far so nobly advanced. It is rather for us to be here dedicated to the great task remaining before us—that from these honored dead we take increased devotion to that cause for which they gave the last full measure of devotion—that we here highly resolve that these dead shall not have died in vain—that this nation, under God, shall have a new birth of freedom—and that government of the people, by the people, for the people, shall not perish from the earth.
>
> —Abraham Lincoln

  * Cuando el docente te lo indique, explora el siguiente applet.

<iframe src="https://www.rossmanchance.com/applets/2021/sampling/OneSample.html?language=1?population=gettysburg" style="border: none; width: 100%; height: 1150px;"></iframe>

<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Después de explorar el applet, haz clic aquí </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  1. Selecciona *Mostrar las opciones de muestreo*.
  2. Observa el apartado que dice *Número de muestras* y *Tamaño de la muestra*. ¿Qué significan estos valores?
  3. Utilizando los valores por defecto del applet (Número de muestras igual a 1 y Tamaño de la muestra igual a 10), haz clic en *Seleccionar muestras*.
  4. ¿Con que información consideras se construye la gráfica *Muestra más reciente*? ¿Y la gráfica *Estadísticos*?
  5. Sin cambiar los valores del número y tamaño de las muestras, haz clic varias veces en *Seleccionar muestras*. ¿Qué ocurrió con las gráficas inferiores?
  6. Aumenta el valor de *Número de muestras* a 250, ¿qué ocurrió con la gráfica *Estadísticos*? Anota el promedio que obtienes en esta gráfica.
 </div>
</details>

<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Qué valor obtuviste en el promedio de la gráfica *Estadísticos*? ¿Qué tan cercano fue del promedio que obtuviste de la longitud de palabras del discurso $$\mu=4.295$$?
* ¿Qué efecto tiene el aumentar o disminuir la variable *Número de muestras* con un *Tamaño de la muestra* fijo?
* ¿Qué efecto tiene el aumentar o disminuir la variable *Tamaño de muestra* con un *Número de muestras* fijo?
* Si tu quisieras tener una buena estimación de la longitud promedio de las palabras del discurso, ¿qué procedimiento consideras te proporcione una idea más certera del valor promedio real: seleccionar una muestra según un criterio que tu establezcas o repetir muchas veces un muestreo de las palabras y cálcular el promedio de esas muestras cada vez? ¿por qué?
* ¿Cuáles consideras son posibles motivos por los cuales se toman muestras para analizar datos en vez de analizar a toda la población?



