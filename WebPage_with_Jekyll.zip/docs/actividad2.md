---
title: Actividad 2
subtitle: Distinguir las distribuciones
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/2.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

Analizar cómo, a medida que aumenta el tamaño de la muestra o se recopilan más datos, es más probable que la muestra brinde una estimación poco variable del parámetro de la población bajo estudio.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

### Distinguiendo distribuciones

<style>
  .image-text-container {
    display: grid;
    grid-template-columns: auto 1fr;
    align-items: center;
    grid-gap: 20px;
  }
</style>

<div class="image-text-container">
  <div>
    <img src="https://github.com/Maleniski/repositorio_imagenes/raw/main/img_distribuciones-muestrales-PT-UNADM/3_dot_plots_v2.png" alt="Dot plots" style="width: 466;">
</div>
  <div>
   Analiza los siguientes dot plots. Para las clases A, B y C, ¿cuál es la principal característica que distingue a estos tres gráficos entre sí? ¿Qué podría explicar esta diferencia? 
    <br>
    <details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Aclarando algunas ideas (clic hasta que el docente lo indique) </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  * ¿Qué características son fundamentales examinar cuando se describen distribuciones?
  * Cuando ves un gráfico de puntos, ¿qué tipo de cualidades del diagrama son relevantes para entender el comportamiento de los datos?
 </div>
</details>
 </div>
</div>


### Crecimiento del tamaño de la muestra

¿Recuerdas el cuestionario perfilador? ¿Qué edad crees que tienen los estudiantes de LM y LCC que se inscribieron al curso de estadística de este semestre? ¡Obtuvimos 49 repuestas! Vamos a analizar esta información realizando muestreos aleatorios de esta información. Para ello, puedes utilizar [EXCEL](https://github.com/Maleniski/repositorio_imagenes/raw/main/img_distribuciones-muestrales-PT-UNADM/Muestra_promedio_edades.xlsm){:target="_blank"} o [COLAB](https://colab.research.google.com/drive/1WNfEPLKeFpaYz3FiQCEoZV7nWPOHGBla?usp=sharing){:target="_blank"} .

  1. Selecciona una muestra aleatoria de cinco valores de edad y realiza un dot plot con esos datos.
  2. Toma dos muestras aleatorias adicionales y agrégalas al dot plot anterior.
  3. Basado en la información de tus muestras ¿Cuál consideras sería un posible dot plot de las 49 edades?
  4. Repite los pasos del 1 al 3 pero realizando ahora un muestreo de las calificaciones promedio obtenidas en el cuestionario perfilador. 


<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Qué comprendes respecto al término distribución de frecuencias?
* ¿Qué información podemos extraer de una distribución?
* ¿Qué información proporciona un histograma? ¿Cuándo prefieres un histograma sobre un dot plot?
* ¿Qué información consideras puede ocultarse en un histograma?
