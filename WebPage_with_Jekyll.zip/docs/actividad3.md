---
title: Actividad 3
subtitle: Muestras grandes
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/3.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

Evaluar cómo muestras aleatorias más grandes tienen mayor probabilidad de ser representativas de la población bajo estudio, en comparación con muestras aleatorias más pequeñas considerando distintas distribuciones.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

Explora el siguiente applet. Cuando el docente te lo indique, ve a la parte inferior de la página y haz clic en el botón *Después de explorar el applet, haz clic aquí*.

<iframe src="https://maleniski.shinyapps.io/actividad_1_v2/" style="border: none; width: 100%; height: 680px;"></iframe>

<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Después de explorar el applet, haz clic aquí </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  1. Selecciona la distribución *Uniforme*.
  2. Mueve el deslizador del tamaño máximo de la muestra al valor 100.
  3. ¿Qué representa el eje *x* de la gráfica? ¿Y el eje *y*?
  4. ¿Cómo son la media teórica y la estimación ésta? ¿Y cómo es la desviación estándar teórica con respecto a la estimación de ésta?
  5. Mueve el deslizador para aumentar el tamaño máximo de la muestra a 500. Observa la gráfica. ¿Qué ocurre con las estimaciones de la media y la desviación estándar conforme se aumenta el tamaño de la muestra?
  6. Repite los pasos del 1 al 6 con el resto de las distribuciones, ¿ves algún comportamiento que se repite?, ¿influye el tipo de distribución en las estimaciones de la media y la desviación estándar? 
 </div>
</details>

<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Consideras que puede ser útil conocer una estimación de los parámetros de una distribución? ¿Por qué?
* ¿Qué sucedía con los valores de la estimación de la media y la desviación estándar cuando se aumentaba el tamaño de la muestra?
* Si utilizaras los valores de la estimación de la media y la desviación estándar calculados a partir de un tamaño de muestra grande, ¿cómo sería esta distribución con respecto a la distribución teórica?
* En el applet para cada tamaño de muestra, y bajo el supuesto de una muestra aleatoria, se calculaba la media y desviación estándar como

$$
\bar{x}_n = \frac{\sum_{i=1}^n x_i}{n}
$$

y

$$
s_n = \sqrt{\frac{\sum_{i=1}^{n}(x_i-\bar{x}_n)^2}{n-1}},
$$

respectivamente. Según lo visto en el applet, cuando modificabas el tamaño de muestra $$n$$, ¿qué comportamiento presentaban la estimación de la media, $$\bar{x}_n $$, y la estimación de la desviación estándar, $$s_n$$?

Se puede demostrar que $$\bar{x}_n$$ converge a la media teórica, y $$s_n$$ converge a la desviación estándar teórica. 

* Imagina que el muestreo de los datos no se realizó de manera aleatoria, ¿qué puedes concluir respecto a los estimadores anteriores calculados bajo un muestreo con estas características?
