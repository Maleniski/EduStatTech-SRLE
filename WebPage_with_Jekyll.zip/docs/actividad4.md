---
title: Actividad 4
subtitle: ¿Más es mejor?
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/4.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">


<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

1. Comprender que la representatividad de una muestra no está necesariamente relacionada con que ésta represente un porcentaje específico del tamaño de la población.
2. Entender que una muestra bien seleccionada puede ser representativa, incluso si solamente es un pequeño porcentaje de la población total.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

Explora el siguiente applet. Cuando el docente te lo indique, ve a la parte inferior de la página y haz clic en el botón *Después de explorar el applet, haz clic aquí*.

<iframe src="https://maleniski.shinyapps.io/actividad_2/" style="border: none; width: 100%; height: 720px;"></iframe>

<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Después de explorar el applet, haz clic aquí </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  1. ¿Existe alguna relación entre el tamaño de la muestra y el tamaño de la población?
  2. Visualiza la gráfica de pendientes. ¿Qué valores se modifican en la gráfica cuando mueves el tamaño de la muestra y el tamaño de la población? ¿Los valores teóricos cambian o se mantienen fijos? Con respecto a los valores estimados ¿cambian o no, cuando mueves los deslizadores?
  3. ¿Qué significa que las rectas cambien de pendiente con respecto al valor de los estimadores y los valores teóricos? 
  4. ¿Qué significaría que la recta tenga pendiente igual a cero con respecto a los valores de los estimadores y los valores teóricos?
  5. Toma el valor pequeño del tamaño de la muestra y un valor grande del tamaño de la población, ¿qué porcentaje de la población representa?, ¿consideras que la diferencia entre los valores estimados y los valores téoricos son muy diferentes?  
  6. Fija el tamaño de la población, si aumentas el tamaño de muestra, ¿es seguro que el valor de la pendiente va a seguir acercándose al cero?
  7. Cambia los valores de los deslizadores, ¿consideras que aumentar el tamaño de la muestra mejora o empeora sustancialmente el valor de las estimaciones?
  8. ¿Aumentar el porcentaje de la población muestreada garantiza una mejor estimación?
 </div>
</details>

<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

1. ¿Es posible obtener una buena estimación de parámetros de una distribución a través del uso de muestras pequeñas?
2. ¿Cuándo puede ser útil identificar condiciones donde con muestras pequeñas podamos obtener un buen estimador de los parámetros de una distribución? 
3. ¿Qué pasaría si la población donde se va a muestrear no es homogénea? Por ejemplo, medir niveles de glucosa entre niños, adultos y ancianos. ¿Cómo cambiarías tu procedimiento para que puedas seguir muestreando utilizando muestras pequeñas?
