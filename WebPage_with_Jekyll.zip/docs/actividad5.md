---
title: Actividad 5
subtitle: Muestreo de una población
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/5.png
layout: page
hero_darken: true
show_sidebar: false
---

<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

1.  Analizar la variabilidad del estadístico bajo estudio de una muestra a otra.
2.	Analizar la variabilidad entre muestras cambiando el tamaño de éstas, bajo una selección aleatoria.
3.	Comprender los tres niveles de datos involucrados en la simulación de muestras aleatorias: la distribución poblacional, la muestra aleatoria individual y la distribución del estadístico.
4.	Entender cómo y por qué los valores del estadístico, calculado a partir de una muestra pequeña, varían más que los calculados a partir de una muestra grande.
5.	Comprender que los valores que toma un estadístico calculado a partir varias muestras pueden ser agrupados y resumidos a través de una distribución de frecuencias.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

### Algunas poblaciones de dulces heterogéneas

<style>
  .image-text-container {
    display: grid;
    grid-template-columns: auto 1fr;
    align-items: center;
    grid-gap: 20px;
  }
</style>

<div class="image-text-container">
  <div>
    <img src="https://github.com/Maleniski/repositorio_imagenes/raw/bffd671ee035fe625c34291675352b40294265b3/img_distribuciones-muestrales-PT-UNADM/chocolates.jpeg" alt="Chocolates" style="width: 622;">
</div>
  <div>
    Estos son chocolates que se caracterizan por tener diferentes cantidades de colores en cada bote o empaque. Si compraras una bolsa de estos chocolates, ¿cómo esperarías que fuera la proporción de chocolates de cada color en el empaque? 
    <br>
    <br>
   <details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Clic cuando ya tengas tu muestra de chocolatitos</summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  1. ¿Cuál será la proporción de chocolates de cada color de la bolsa?
  2. Si en el grupo sacaramos 10 muestras de 25 chocolatitos, ¿en cada muestra cual sería la proporción de los chocolates de color naranja?
  3. ¿Cuántos chocolates naranjas hay en tu muestra?
    
  Analizaremos tus resultados y los de tus compañeros.
 </div>
</details> 
 </div>
</div>


### Pasando de los chocolatitos reales a los digitales

Cuando el docente te lo indique, explora el siguiente applet.

<iframe src="https://www.rossmanchance.com/applets/2021/oneprop/OneProp.htm?candy=1&language=5" style="border: none; width: 100%; height: 1020px;"></iframe>

<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Después de explorar el applet, haz clic aquí </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  Selecciona *Proporción de caramelos naranjos* en el apartado *Elige estadístico*.
    
  1. Realiza lo siguiente, anotando los valores que toma la proporción.
  *	Simula una muestra de tamaño de tamaño 25.
  *	Simula una muestra de tamaño de tamaño 50.
  *	Simula una muestra de tamaño 100.
  2. Realiza lo siguiente, anotando el rango de valores que tomó la proporción en tu simulación.
  * Simulando 100 muestras de tamaño 25.
  * Simulando 100 muestras de tamaño de tamaño 50.
  * Simulando 100 muestras de tamaño 100.
 </div>
</details>

<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Qué características pueden variar en los datos de una misma muestra?
* ¿Qué características pueden variar de muestra a muestra?
* ¿Qué pasaba en el applet cuando aumentabas los valores de la muestra de chocolatitos?

¿Recuerdas la ley de los grandes números?

Sean $$X_1$$, $$X_2$$, ..., $$X_n$$ v.a. i.i.d. con media $$\mu$$ y varianza $$\sigma^2$$ finitas. Entonces, para todo $$\epsilon>0$$

$$
\lim_{n\rightarrow\infty} P(|\bar{X}_n-\mu|< \epsilon)=1
$$

* En la ley de los grandes números, ¿qué pasa al hacer crecer el tamaño de la muestra, $$n$$? 
* ¿Qué tamaño crees que deba tener una muestra para representar una población?
* ¿Qué utilidad tendrá el poder simular los datos de una población, como por ejemplo, simular muestras de chocolatitos?


