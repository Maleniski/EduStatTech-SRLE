---
title: Actividad 6
subtitle: Muestras grandes, estadísticos buenos
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/6.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

1. Comprender que la simulación de la distribución de un estadístico, calculado a partir muestras grandes, es una buena aproximación a la distribución muestral teórica de éste. 
2. Comprender que en un número grande de muestreos es más importante el tamaño de muestra y no la cantidad de veces que se muestrea.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

Explora el siguiente applet. Cuando el docente te lo indique, ve a la parte inferior de la página y haz clic en el botón *Después de explorar el applet, haz clic aquí*.

<iframe src="https://maleniski.shinyapps.io/act_adap_gude_3y4/" style="border: none; width: 100%; height: 670px;"></iframe>


<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Después de explorar el applet, haz clic aquí </summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  1. Selecciona la distribución normal.
  2. ¿Qué efectos tiene el tamaño de la muestra sobre el histograma?
  3. ¿Qué efectos tiene el número de iteraciones sobre el histograma?
  4. ¿Cómo está variando la media de las medias cuando cambias el tamaño de la muestra? ¿Qué ocurre con la media de las medias cuando cambias el número de iteraciones?
  5. ¿Cómo está variando la desviación estándar de las medias cuando cambias el tamaño de la muestra? ¿Qué ocurre con la desviación estándar de las medias cuando cambias el número de iteraciones?
  6. Selecciona otra distribución, y realiza los análisis sugeridos en 2, 3, 4 y 5, ¿qué cambios observas con esta nueva distribución? ¿qué cambios observas con respecto a los cambios ocurridos en la distribución normal? ¿son comportamientos similares o diferentes?
 </div>
</details>

<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* El Teorema del Límite Central (TLC) nos garantiza que si tenemos una muestra aleatoria de tamaño $$n$$ (con $$n$$ suficientemente grande), $$\bar{X}_n\sim N(\mu, \frac{\sigma^2}{n})$$, es decir, la media muestral se distribuirá normalmente con media $$\mu$$ y varianza $$\frac{\sigma^2}{n}$$. Según el TLC, al aumentar el tamaño de muestra ¿qué ocurre con la desviación estándar de la media muestral? ¿qué ocurre con la media de las medias muestrales?
* En el applet, cuando cambiabas el tamaño de la muestra, ¿qué ocurría en el histograma? ¿qué comportamiento observas para el promedio de las medias estimadas en el applet? ¿y del comportamiento de la desviación estándar calculada a partir de las medias?
* Según lo visto en el applet y por lo enunciado en el TLC, ¿la aproximación de la media muestral $$\bar{X}_n$$ mejora cuando aumentas el tamaño de la muestra o aumentando las veces que remuestreas? ¿por qué?
* ¿Consideras que la convergencia que viste en el applet a la distribución normal se ve influenciada por la distribución con la que se generaron los datos? ¿por qué?
