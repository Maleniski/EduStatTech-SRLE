---
title: Actividad 7
subtitle: Generación de distribuciones muestrales
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/7.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

Evaluar la variación de los valores del estadístico considerando que dependen del parámetro, comprendiendo que esta variación se puede anticipar.


<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

### Temperaturas corporales

**¿Normal o inusual?**

* ¿Cuál es una temperatura inusual para alguien que no este enfermo?
* ¿Cuándo considerarías que una temperatura es suficientente grande o pequeña como para seguir considerando que no este enfermo?
* Dibuja una distribución que represente la temperatura corporal de un adulto sano.
* Piensa en las temperaturas corporales de un adulto: 37.2 ° C, 36.7 ° C y 36.2 ° C. En tu experiencia, ¿cómo las considerarías? ¿el adulto está sano o enfermo?
* Según tu gráfica, ¿los valores 37.2 ° C, 36.7 ° C y 36.2 ° C son inusuales? ¿y para 35.6 ° C?

Entonces... ¿cuándo un valor es inusual o sorprente?

**Los $$z$$-scores**

Los $$z$$-scores es una medida estadística que cuantifica el número de desviaciones estándar que tiene un punto respecto a la media de una distribución. Se utiliza para estandarizar datos de una distribución normal, lo que ayuda a comparar datos normales con diferentes parámetros.

¿Cómo lo definimos?

$$
z = \frac{X - \mu}{\sigma}
$$

donde

* $$X$$ es el valor del dato;
* $$\mu$$ es la media teórica de los datos;
* $$\sigma$$ es la desviación estándar teórica de los datos.

Hay artículos (por ejemplo, [éste](https://www.tandfonline.com/doi/abs/10.1080/07420528.2019.1663863?journalCode=icbi20){:target="_blank"}) donde logran estimar que la temperatura promedio de los humanos es 36.7°C con una desviación estándar de 0.6°C. ¿Recuerdas los valores 37.2 ° C, 36.7 ° C y 36.2 ° C? ¿Cómo son sus $$z$$-scores? ¿Grandes, pequeños?

<i class="fa-solid fa-chart-line"></i> Tiempo de una dinámica de captura de datos.

* Tomen una muestra aleatoria de 10 estudiantes a los que se les toma la temperatura, y anoten las temperaturas en el pizarrón.
* ¿Consideras que la temperatura promedio de esta muestra será exactamente 36.6°C o cercana a este valor? ¿Por qué?
* ¿Qué pasaría si tomaras otra muestra aleatoria 10 estudiantes? ¿Esta muestra tendría la misma media que la primera muestra de 10 o tendría una media diferente? ¿Por qué?

<i class="fa-solid fa-users"></i> Tiempo de una actividad en parejas. 

1. Escribe cinco valores plausibles de las temperatuas corporales de estudiantes.
2. Imagina que tomas la temperatura de cinco muestras aleatorias de diez estudiantes. Es decir, resultas con 5 promedios de temperaturas. ¿Cuál tendría más variabilidad, la que son cinco valores propuestos en el punto 1, o los cinco promedios obtenidos de estas muestras? ¿Por qué?
3. Proporciona cinco valores plausibles de medias de temperaturas con muestras aleatorias de tamaño 100. ¡Comparemos tus conjeturas simulando valores en el applet!
4. ¿Cuál crees que sería la distribución de medias de muestras aleatorias de tamaño 100?

<iframe src="https://maleniski.shinyapps.io/applet_act_7/" style="border: none; width: 100%; height: 680px;"></iframe>

### Muestreo de palabras

Explora el applet. 

<iframe src="https://www.rossmanchance.com/applets/2021/sampling/OneSample.html?language=1?population=gettysburg" style="border: none; width: 100%; height: 1150px;"></iframe>

Instrucciones.

1. Activa *Mostrar las opciones de muestreo* en el applet.
2. Toma una muestra de cinco palabras. ¿Cuáles son las longitudes de las cinco palabras que te tocaron? ¿Cómo fueron las longitudes de las cinco palabras de tus compañeros?
3. Registra la media y desviación estándar de tu muestra de cinco longitudes, ¿cuál sería un valor inusual de longitud de palabras del discurso?
4. Compara la media y la desviación estándar de tu muestra de cinco longitudes de palabra con los valores poblacionales de todo el discurso ($$\mu$$=4.295
 y $$\sigma$$=2.119).
5. En el applet calcula muchas muestras de tamaño 5, y examina el histograma de las medias muestrales. ¿Cuáles serían valores inusuales de las medias para muestras de tamaño 5? Proporciona criterios que tu considerarías para identificar un valor sorprendente.
6. Genera una distribución de 500 medias muestrales utilizando muestras de tamaño 5.
7. Selecciona un valor hipotético que longitud promedio que consideres "inusual".
8. Dentro de esta distribución muestral que generaste en el paso 6, ubica ahora tu valor inusual.
9. Cambia el tamaño de la muestra a 16 y determina cómo afecta esto a una nueva distribución de 500 medias muestrales. Ubica de nuevo tu valor inusual en esta distribución.
10. Repite el proceso en el paso 7 para muestras de tamaño 25 y 100.
11. ¿Cómo calcularías el $$z$$-score de tu valor inusual en las distribuciones que has construído?

### Muestreo de monedas

1. En el applet mostrado arriba, en *Pegar datos de población o seleccionar de la lista* selecciona *pennies*.
2. Simula muestras de esta población.
3. Observa si se presenta algún predecible en los años de los peniques al generar distribuciones de las medias muestrales utilizando el applet.
4. Varia los parámetros del applet comenzando con tamaños de muestra pequeños y aumentando progresivamente a tamaños de muestra más grandes, tomando 500 muestras en cada caso y observando la distribución de las medias muestrales.
5. ¿Hay un patrón en la distribución de la media muestral? ¿Este patrón cambia con el tamaño de la muestra o es invariante?


<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Cuáles son las temperaturas corporales más probables en una población normal y cómo se determina su posición relativa en la distribución?
* ¿Cómo nos ayuda el número de desviaciones estándar por encima y por debajo de la media ($$z$$-scores) para determinar si un valor es poco probable o inusual?
* ¿Qué diferencias hay entre la variabilidad de las temperaturas corporales individuales y la variabilidad de temperaturas promedio muestrales?
* ¿Por qué las medias de muestras pequeñas varían más que las de muestras grandes?
* ¿Cuál es el patrón predecible que observamos cuando tomamos muestras de mayor tamaño y graficamos sus medias?
* ¿Por qué es importante comparar una media muestral con muchas otras medias muestrales del mismo tamaño y de la misma población para determinar si es inusual o sorprendente?
* ¿Cómo podemos utilizar las $$z$$-scores para evaluar si los valores de una distribución de medias muestrales normal son poco probables o sorprendentes?
