---
title: Actividad 8
subtitle: Descripción del patrón predecible, el teorema del límite central
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/8.png
layout: page
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<h2><i class="fa-solid fa-book-open"></i> Objetivos de aprendizaje</h2>
---

1.	Determinar cuándo y por qué la distribución de una muestra adquiere una forma acampanada.
2.	Comprender que la distribución muestral de la media calculada a partir de muestras aleatorias grandes tiende a mostrar un comportamiento regular.
3.	Comprender cómo el Teorema del Límite Central describe la forma, el centro y la dispersión de la distribución muestral de un estadístico.

<h2><i class="fa-solid fa-chalkboard-user"></i> Desarrollo</h2>
---

Tu docente te proporcionará dos hojas las cuales utilizarás en esta actividad, una llamada *Hoja 1 para el estudiante* y otra llamada *Hoja 2 para el estudiante*. En la Hoja 1 podrás encontrar una tabla en donde cada columna representa el histograma de la media muestral de una población específica considerando diferentes tamaños de muestra pero repitiendo el muestreo 500 veces. En la Hoja 2, se tiene en el primer renglón una descripción de las tres poblaciones diferentes. Si no tienes hojas, puedes localizar las hojas haciendo clic <i class="fa-solid fa-arrow-right"></i> **[aquí](https://drive.google.com/file/d/1g1G9KEZvnbsQ9OX5VgmNC3gKEX2cpNU5/view?usp=sharing){:target="_blank"}** <i class="fa-solid fa-arrow-left"></i>. Tu trabajo es el siguiente:

1. En la primera columna de la Hoja 2, vas a subrayar o marcar la distribución muestral de la media que consideras corresponde al tamaño de muestra utilizado, $$n$$, y la media y desviación estándar de $$\bar{x}$$ con las distribuciones mostradas de la columna 1 de la Hoja 1. Puedes seleccionar A, B, C o D. *Hint*: para poder responder, presta mucha atención en el **tamaño** de la muestra que se toma para calcular la medias, así como también la **localización** y **variabilidad** de la distribución para poderlas identificar.
2. Repite el paso anterior con las columnas 2 y 3 de la Hoja 2, utilizando las respectivas columnas de la Hoja 1.
3. Recorta los cuadritos de las gráficas de la Hoja 1.
4. Ingresa al siguiente applet, y verifica las respuestas que subrayaste o circulaste en la Hoja 2 seleccionando en el applet el tipo y tamaño de la muestra. 
5. Una vez que identifiques qué gráfica debe de ir en cada rectángulo, avisa a tu docente.
6. El docente te mostrará las respuestas correctas. Pega la gráfica en el recuadro correspondiente.
7. Revisa esta otra hoja de trabajo similar a la tuya. ¿Qué comportamientos ves en las gráficas? ¿El resultado es similar al que obtuviste tu?
<details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> Otra hoja de trabajo (haz clic hasta que llegues a esta parte de la actividad) </summary>
<br>
 <img src="https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/Hoja_Trabajo_Ejemplo2.png" alt="Hoja de trabajo ejemplo 2" width="500" height="auto">

</details>

<br>
¿Ves algún patrón en las gráficas? Discutelo con tu docente y compañeros.

<iframe src="https://maleniski.shinyapps.io/applet_act_8/" style="border: none; width: 100%; height: 670px;"></iframe>

   <details>
<summary style="padding: 5px 10px; border: 1px solid #ccc; background-color: #f9f9f9; display: inline-block; font-size: 18px; font-weight: bold;"><i class="fa fa-caret-right" aria-hidden="true"></i> ¿Qué nos dice el Teorema del Límite Central?</summary>

  <div markdown="1" style="padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; margin-top: 10px;">
  Sean $$X_1$$, $$X_2$$, ..., $$X_n$$ variables aleatorias independientes e idénticamente distribuidas con media $$\mu$$ y varianza $$\sigma^2<\infty$$. Entonces, para cualquier $$x\in\mathbb{R}$$
  
  $$
  \lim_{n\rightarrow\infty}P[\frac{\bar{X}_n-\mu}{\sigma/\sqrt{n}}\leq x] = P[Z\leq x]
  $$
  donde $$Z\sim N(0,1)$$.
    
  Esto es equivalente a que, para $$n$$ suficientemente grande $$\bar{X}_n\sim N(\mu, \frac{\sigma^2}{n})$$.
 </div>
</details>


<h2><i class="fa-solid fa-people-group"></i> Discusión final</h2>
---

* ¿Cuál es la diferencia entre la Ley de los Grandes Números y el Teorema de Límite Central? 
* ¿Están conectados estos dos teoremas o tiene una relación?
* ¿Cuál es la relación entre la distribución de la población y la distribución muestral de la media?
* ¿Cómo podemos describir la distribución muestral de las medias sin realizar simulaciones?
* Para muestras aleatorias de tamaño 100 de una población de temperaturas corporales humanas, ¿cuál sería la forma, el centro y la dispersión de la distribución de las medias muestrales? Recuerda que la distribución de temperaturas en humanos es normal con media $$\mu=$$ 36.7°C y con una desviación estándar de $$\sigma=$$ 0.6°C.
* ¿Y cuál sería más probable que se acercara más a 36.7 ° C: una temperatura media basada en 9 personas o una temperatura media basada en 25 personas?
