---
title: Secuencia didáctica de distribución muestral de la media
subtitle: Un proyecto bilateral UnADM-UNISON
layout: page
hero_image: https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/student_learning_stat_data.jpg
hero_darken: true
show_sidebar: false
---

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">

# ¡Bienvenido!

Esta página web contiene una serie de actividades orientadas al aprendizaje de la distribución muestral de la media. En cada una de ellas podrás encontrar los objetivos de la actividad, el desarrollo y una discusión de cierre.

Esperamos que tu experiencia navegando y aprendiendo en esta plataforma sea tan enriquecedora como nosotros hemos planeado que sea.

---
![](https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/logo_unadm.jpeg)
![](https://raw.githubusercontent.com/Maleniski/repositorio_imagenes/main/img_distribuciones-muestrales-PT-UNADM/logo-unison.png)
